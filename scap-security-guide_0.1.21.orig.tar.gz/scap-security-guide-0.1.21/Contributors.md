The following people have contributed to the OpenSCAP Security Guide project
(listed in alphabetical order within category):

Developers:
* Gabe Alford
* Christopher Anderson
* Jeff Blank
* Blake Burkhart
* Frank Caviggia
* Eric Christensen
* Caleb Cooper
* Nick Crawford
* Maura Dailey
* Greg Elin
* Andrew Gilmore
* Jeremiah Jahn
* Luke Kordell
* Jan Lieskovsky
* Šimon Lukašík
* Michael McConachie
* Rodney Mercer
* Brian Millett
* Michael Moseley
* Joe Nall
* Michele Newman
* Michael Palmiotto
* Kenneth Peeples
* Martin Preisler
* Rick Renshaw
* Willy Santos
* Satoru Satoh
* Ray Shaw
* Spencer Shimko
* Francisco Slavin
* Dave Smith
* Kevin Spargur
* Kenneth Stailey
* Leland Steinke
* Paul Tittle
* Jeb Trayer
* Shawn Wells

Testing:
