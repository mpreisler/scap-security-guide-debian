echo "*     hard   core    0" >> /etc/security/limits.conf
