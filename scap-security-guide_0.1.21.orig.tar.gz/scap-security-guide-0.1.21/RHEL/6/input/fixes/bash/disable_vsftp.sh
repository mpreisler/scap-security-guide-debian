if service vsftpd status >/dev/null; then
	service vsftpd stop
fi
