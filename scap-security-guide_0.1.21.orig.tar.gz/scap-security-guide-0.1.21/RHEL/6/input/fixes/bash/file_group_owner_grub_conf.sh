chgrp root /etc/grub.conf
