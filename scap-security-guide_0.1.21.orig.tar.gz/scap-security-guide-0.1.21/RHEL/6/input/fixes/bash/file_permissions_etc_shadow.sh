chmod 0000 /etc/shadow
