chmod 600 /boot/grub/grub.conf
