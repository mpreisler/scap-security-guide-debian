chown root /etc/grub.conf
