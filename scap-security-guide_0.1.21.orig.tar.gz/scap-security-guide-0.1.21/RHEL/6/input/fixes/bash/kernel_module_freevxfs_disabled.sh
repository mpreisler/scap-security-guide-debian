echo "install freevxfs /bin/false" > /etc/modprobe.d/freevxfs.conf
