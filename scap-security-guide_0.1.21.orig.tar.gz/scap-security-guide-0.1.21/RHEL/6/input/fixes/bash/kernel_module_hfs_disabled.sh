echo "install hfs /bin/false" > /etc/modprobe.d/hfs.conf
