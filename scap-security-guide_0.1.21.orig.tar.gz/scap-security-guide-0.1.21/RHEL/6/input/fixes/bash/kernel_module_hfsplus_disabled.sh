echo "install hfsplus /bin/false" > /etc/modprobe.d/hfsplus.conf
