echo "install jffs2 /bin/false" > /etc/modprobe.d/jffs2.conf
