echo "install rds /bin/false" > /etc/modprobe.d/rds.conf
