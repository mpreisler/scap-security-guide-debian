echo "install sctp /bin/false" > /etc/modprobe.d/sctp.conf
