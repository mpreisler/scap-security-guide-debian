echo "install squashfs /bin/false" > /etc/modprobe.d/squashfs.conf
