echo "install tipc /bin/false" > /etc/modprobe.d/tipc.conf
