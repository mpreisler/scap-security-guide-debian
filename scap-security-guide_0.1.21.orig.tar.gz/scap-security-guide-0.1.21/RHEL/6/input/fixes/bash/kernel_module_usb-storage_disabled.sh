echo "install usb-storage /bin/false" > /etc/modprobe.d/usb-storage.conf
