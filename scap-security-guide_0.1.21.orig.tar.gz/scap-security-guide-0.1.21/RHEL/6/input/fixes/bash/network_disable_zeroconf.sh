echo "NOZEROCONF=yes" >> /etc/sysconfig/network
