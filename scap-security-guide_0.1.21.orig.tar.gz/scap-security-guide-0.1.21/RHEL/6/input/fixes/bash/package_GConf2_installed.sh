yum -y install GConf2
