yum -y install aide
