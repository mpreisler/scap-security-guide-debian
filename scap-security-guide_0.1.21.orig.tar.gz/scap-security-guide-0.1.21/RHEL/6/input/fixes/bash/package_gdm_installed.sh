yum -y install gdm
